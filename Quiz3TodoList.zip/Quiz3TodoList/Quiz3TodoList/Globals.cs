﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quiz3TodoList
{
    class Globals
    {
        public static Database db;
        public static string option;
        public static string statusBar;
    }
}
